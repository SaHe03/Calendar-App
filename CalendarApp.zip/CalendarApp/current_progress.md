# Current Progress

> **Code modification permission:** Do not edit, create, delete, format, or otherwise modify application code or project files without the user's explicit permission. Default to read-only inspection and teaching guidance.

## Developer Background

I am a senior majoring in computer science with programming experience in C++, C, Java, and Python.

## Project Goal

I am creating a multipurpose calendar app to replace several separate apps that I currently use. The finished app is intended to combine:

- A standard calendar
- A to-do list
- A period tracker
- A habit tracker

## Current Development Stage

I am currently building the foundation of the app. At this stage, it should function as a simple calendar. Additional tracking and productivity features will be added as development progresses.

## Work Completed

- Used Codex to help identify and resolve issues involving project dependencies and Android imports.
- Removed some Kotlin (`.kt`) UI files that were preventing the project from building.
- Confirmed during the most recent check that the project appeared capable of building successfully.

## Testing and Next Steps

Android Studio's Device Manager provides a built-in emulator that can be used to run and test the application. The next step is to verify the current build in the emulator and continue developing the basic calendar functionality.

## Future Feature Architecture

The application is expected to use a hybrid storage model. Information will be stored according to its feature type and associated with a date. When a user selects a day on the calendar, the daily calendar view will retrieve and combine matching records from each feature. This keeps the calendar day as a presentation layer while allowing each feature to be searched, sorted, and analyzed independently.

### Appointments

Appointments currently contain a date key, title, and time stored as strings. They are queried by date and displayed as simple text. Optional details such as an end time or notes may be added later.

### Habits

Habit checks currently associate a habit name and date key with a Boolean `complete` value. Incomplete and unrecorded are intentionally equivalent: `false` means unchecked and `true` means checked. The desired future interface will display habits as checkboxes rather than plain summary text.

### Period Tracking

Period information is represented by daily logs associated with dates. `List<PeriodLog>` holds these records for future grouping and calculations. A placeholder `PeriodCycle` with `LocalDate` start and end dates exists, but duration, history, and prediction logic are not implemented.

### Daily Calendar View

The selected calendar day acts as a combined presentation rather than permanent storage. The current implementation gathers matching feature records into multiline text below the calendar. Separate interactive controls are desired later.

## Session Handoff: Kotlin Learning and Hybrid Model

### Concepts Learned

- Android's `CalendarView` supplies months using zero-based numbering, so one must be added when producing a human-readable month.
- A date can be used as a lookup key for associated information.
- A `List<String>` allows one date to contain multiple independent entries.
- A missing map entry can be handled with a default message instead of causing an error.
- `CalendarView` does not supply holidays. Holidays must come from maintained application data, a bundled dataset, a device calendar, or an external service.

### Hybrid Model Decision

Feature records will own the stored data, while the selected calendar day will combine matching records for presentation. Appointments, habit checks, and period logs will remain separate types and collections but share a consistent date key. This supports both a daily view and feature-specific sorting, filtering, history, and analysis.

Habit completion currently uses a Boolean because incomplete and unrecorded are intentionally treated as the same unchecked state. This replaces the earlier three-state recommendation.

### Current Application State

- The app contains a `CalendarView`, a top selected-date `TextView`, and a daily-summary `TextView` below the calendar, managed by `MainActivity.kt`.
- The selected-date interpolation issue has been fixed. The top view uses `MM/DD/YYYY`, while lookup keys use `YYYY-MM-DD`.
- `buildDailySummary` filters the three feature lists and returns labeled text sections or a default message.
- Appointments include a string `time` argument and display it alongside the title.
- Habits use a Boolean `complete` property and are still rendered as text rather than checkboxes.
- Period logs remain daily records. `PeriodCycle` exists as an early placeholder for future multi-day calculations.
- In-memory sample collections are for learning only. User-entered information and permanent database storage have not yet been implemented.

### Teaching Materials
- `lessons/0001-date-to-information.html` introduces date-key lookup and default handling.
- `lessons/0002-combine-feature-records-by-date.html` teaches separate feature data classes, habit states, filtering by date, and a combined daily summary.
- `reference/hybrid-data-model.html` is the quick reference for the chosen architecture.
- `learning-records/0001-date-lookup-foundations.md` records the concepts demonstrated after lesson 0001.

### Next Step

Continue lesson 0002. The user will add the Kotlin declarations and logic personally, test a date containing sample records, test a date with no records, and explain which objects own the data versus which function combines it for display. User input controls and persistent storage should come only after this hybrid retrieval flow is understood.

## Session Update: Daily Summary UI and Feature Decisions

- Added separate `Appointment`, `HabitCheck`, and `PeriodLog` data classes with in-memory sample records.
- Added `buildDailySummary(dateKey: String)` to filter feature collections by date and combine matching records for display.
- Added and initialized a second `TextView`, `dailySummaryText`, below the `CalendarView`. The top `TextView` remains dedicated to the selected date.
- Selected dates display as `MM/DD/YYYY`; feature matching continues to use `YYYY-MM-DD` string keys.
- Fixed the uninitialized `dailySummaryText` crash path and an accidental character that prevented compilation.
- `Appointment` now contains `dateKey: String`, `title: String`, and `time: String`. Appointment time is currently stored and displayed as a string.
- Habit completion uses `Boolean`: checked/complete is `true`, while incomplete or unrecorded is `false`.
- The desired later UI keeps appointments as text, displays habits as checkboxes, and presents period information as a compact clickable entry with details and possible preset flow-based colors.
- `PeriodLog` represents one recorded day, and `List<PeriodLog>` holds logs for later calculations. `PeriodCycle` has been introduced with `LocalDate` start and end dates, but grouping, duration, history, and prediction logic are not implemented.
- The daily summary currently updates after a date-selection event. Automatically populating the initially selected date at startup remains future work.

### Immediate Verification

Test a date for each feature, a date with no records, and a date with multiple feature types. Confirm that feature lists own the records and `buildDailySummary` only combines matching records for presentation. Interactive controls, user input, permanent storage, and period calculations come later.

## Session Handoff: Lesson 3 - Appointment User Input

- Lesson 0002 is complete. Treat hybrid retrieval and feature-record ownership as understood.
- Habits should eventually use real interactive Android `CheckBox` views connected through XML and Kotlin, not checkbox characters or Boolean text in `dailySummaryText`.
- The user invoked the `teach` skill to learn user input. Create `lessons/0003-add-an-appointment-from-user-input.html` next.
- Scope lesson 0003 to one win: select a date, enter an appointment title and time in XML `EditText` controls, tap an Add `Button`, add an `Appointment` to an in-memory mutable collection, and refresh the selected day summary.
- Teach this pipeline: XML inputs -> click listener -> read and trim -> validate -> construct `Appointment` -> add to `MutableList` -> explicitly refresh.
- Introduce a nullable activity property such as `selectedDateKey` to share the calendar callback date key with the later button callback.
- Explain that changing `appointments` from `listOf` to `mutableListOf` enables additions but not persistence; added records disappear after restart.
- Include missing-date and blank-field validation, emulator tests, retrieval questions, and official Android/Kotlin sources.
- Create a compact input-pipeline reference, update `RESOURCES.md` with official `EditText`, `Button`, and mutable-collection documentation, and record lesson-2 completion when appropriate.
- Do not modify application code. The user types the XML and Kotlin changes during the lesson.
- Lesson 0003 was planned but not created because `codex-windows-sandbox-setup.exe` was unavailable and fallback patch attempts failed. Retry teaching-file creation after reopening the terminal.

## Session Update: Lesson 3 and Appointment Panels

### Lesson 3 Materials

- Created `lessons/0003-add-an-appointment-from-user-input.html`.
- Created `reference/appointment-input-pipeline.html` as a compact reference for sharing the selected date between callbacks, validating text input, constructing an `Appointment`, adding it to a collection, and refreshing the daily summary.
- Added `learning-records/0002-hybrid-record-ownership.md` to record completion of the lesson-2 ownership foundation.
- Updated `RESOURCES.md` with official Android documentation for `EditText` and `Button` and official Kotlin documentation for mutable collections and collection write operations.
- Lesson 3 originally used an in-memory `MutableList` as a teaching step. The user correctly rejected in-memory storage as the finished architecture because appointments must survive application restarts. Persistent structured storage, preferably Room, is required in a future lesson before appointment storage is considered complete.

### Current Appointment UI

- `custom_cal_view.xml` now contains two panels below the calendar:
  - `summary_Panel` contains `dailySummaryText` and `showAppointmentFormButton`.
  - `edit_Panel` contains `appointmentTitleInput`, `appointmentTimeInput`, and `addAppointmentButton`.
- The intended interaction is state-based: the summary panel is shown normally; tapping the show-form button hides it and displays the edit panel; successfully adding an appointment refreshes the summary, hides the edit panel, and restores the summary panel.
- The panel controls are now nested inside their respective `LinearLayout` containers. Relative-layout positioning attributes on children of a `LinearLayout` are unnecessary and should not be relied upon.
- `edit_Panel` should begin with `android:visibility="gone"`. Whenever a calendar date is selected, Kotlin should explicitly show `summary_Panel` and hide `edit_Panel`.
- Validation should use visible errors on `appointmentTitleInput` and `appointmentTimeInput`. Writing a validation message to `dailySummaryText` while `summary_Panel` is hidden makes the message invisible.
- The Add/Save listener intentionally keeps the edit panel open when no date is selected or a required field is blank. It hides the edit panel only after validation succeeds and an appointment is added.

### Current Kotlin Input Flow

- `selectedDateKey: String?` shares the selected calendar date between the calendar listener and appointment button listener.
- `appointments` currently uses `mutableListOf`, so appointments can be added during the running process.
- The show-form listener switches from `summary_Panel` to `edit_Panel`.
- The Add/Save listener reads and trims the title and time, validates the selected date and fields, constructs an `Appointment`, adds it to `appointments`, clears the inputs, rebuilds `dailySummaryText`, and switches back to the summary panel.
- In-memory additions still disappear after a process restart. Do not treat the current collection as finished appointment storage.

### Next Verification and Development

1. Confirm `edit_Panel` starts as `gone` in XML.
2. Select a date before opening the form, enter both fields, save, and confirm the edit panel disappears and the refreshed summary appears.
3. Test missing-title, missing-time, and missing-date paths and confirm the edit panel stays open with a visible error.
4. Add a Cancel control so the user can leave the edit panel without saving.
5. Replace in-memory appointment storage with Room, then verify that saved appointments remain after restarting the app.
