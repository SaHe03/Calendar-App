package com.example.calendarapp

import android.os.Bundle
import android.view.View
import android.widget.CalendarView
import android.widget.TextView
import androidx.activity.ComponentActivity
import java.time.LocalDate
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

// To hold the information of a date of an appointment/event
data class Appointment(
    val dateKey: String,
    val title: String,
    val time: String
)


// To hold the information of a habit being done
data class HabitCheck(
    val dateKey: String,
    val habitName: String,
    val complete: Boolean
)
// To hold the information of a single period day
data class PeriodLog(
    val dateKey: String,
    val flow: String,
    val notes: String
)
// To deal with the multiday event of a period and related functions to calculate a period
data class PeriodCycle(val startDate: LocalDate, val endDate: LocalDate){
}
//function to add to a growing list, remove/add at random
class MainActivity : ComponentActivity() {

    private lateinit var dateText: TextView
    private lateinit var calendarView: CalendarView
    private lateinit var dailySummaryText: TextView
    private var selectedDateKey: String? = null


    // testing objects
    private val appointments = mutableListOf(Appointment("2026-10-11", "Doctor", "11:30"), Appointment("2026-08-06", "Sleep", "1:30"))
    private val habitChecks = mutableListOf(HabitCheck("2026-08-06","shower",  false))
    private val periodLogs = mutableListOf(PeriodLog("2026-12-11", "heavy", "Heavy cramp"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Load app/src/main/res/layout/custom_cal_view.xml
        setContentView(R.layout.custom_cal_view)
        // declare the panels
        val summaryPanel = findViewById<LinearLayout>(R.id.summaryPanel)
        val editPanel = findViewById<LinearLayout>(R.id.editPanel)
        val showEditPanelButton = findViewById<Button>(R.id.showEditPanelButton)

        // To add appointments, there is a need for asking their name and time, with a button for confirmation
        val appointmentTitleInput = findViewById<EditText>(R.id.appointmentTitleInput)
        val appointmentTimeInput = findViewById<EditText>(R.id.appointmentTimeInput)
        val addAppointmentButton = findViewById<Button>(R.id.addAppointmentButton)

        // button listening behavior for showing the edit panel
        showEditPanelButton.setOnClickListener {
            summaryPanel.visibility = View.GONE
            editPanel.visibility = View.VISIBLE
        }
        // button listening behavior for appointments
        addAppointmentButton.setOnClickListener {
            val dateKey = selectedDateKey
            val title = appointmentTitleInput.text.toString().trim()
            val time = appointmentTimeInput.text.toString().trim()

            if (dateKey == null) {
                dateText.text = "Select a date first"
                return@setOnClickListener
            }
            if (title.isBlank() || time.isBlank()) {
                dailySummaryText.text = "Add both a name and time"
                return@setOnClickListener
            }
            val appointment = Appointment(dateKey, title, time)
            appointments.add(appointment)
            summaryPanel.visibility = View.VISIBLE
            editPanel.visibility = View.GONE
            dailySummaryText.text = buildDailySummary(dateKey)
            appointmentTitleInput.text.clear()
            appointmentTimeInput.text.clear()
        }


        // Obtain references to views declared in that XML file
        dateText = findViewById(R.id.idTVDate)
        calendarView = findViewById(R.id.calendarView)
        dailySummaryText = findViewById(R.id.dailySummaryText)

        calendarView.setOnDateChangeListener {
            _, year, month, dayOfMonth -> val dateKey = "%04d-%02d-%02d".format(year, month + 1, dayOfMonth)
            selectedDateKey = dateKey
            val displayDate = "%02d/%02d/%04d".format(
                month + 1,
                dayOfMonth,
                year
            )
            dateText.text = displayDate
            summaryPanel.visibility = View.VISIBLE
            editPanel.visibility = View.GONE
            dailySummaryText.text = buildDailySummary(dateKey)

        }
    }
    // This will be used for when user selects a date to build the days summary.
    // Find for any features that relate to the day and display them too
    // Move into the creation as the information should be readily availble
    private fun buildDailySummary(dateKey: String): String {
        val dailyAppointments = appointments.filter { it.dateKey == dateKey }
        val dailyHabits = habitChecks.filter { it.dateKey == dateKey }
        val dailyPeriodLogs = periodLogs.filter { it.dateKey == dateKey }
        val sections = mutableListOf<String>()
        if (dailyAppointments.isNotEmpty()) {
            sections.add("Appointments\n" +
                    dailyAppointments.joinToString("\n") {
                        "- ${it.title}: ${it.time}"
                    })
        }
        if (dailyHabits.isNotEmpty()) {
            sections.add("Habits\n" +
                    dailyHabits.joinToString("\n") {
                        "${it.habitName}"
                    })
        }
        if (dailyPeriodLogs.isNotEmpty()) {
            sections.add("Period\n" +
                    dailyPeriodLogs.joinToString("\n") {
                        "- ${it.flow}: ${it.notes}"
                    })
        }
        return if (sections.isEmpty()) {
            "No information for this date"
        } else {
            sections.joinToString("\n\n")
        }
    }

}
