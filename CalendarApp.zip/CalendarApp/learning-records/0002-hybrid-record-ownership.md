# Hybrid record ownership

The user understands that appointment, habit, and period collections own their feature records while `buildDailySummary` filters and combines matching records only for presentation. Future lessons can build on this separation by mutating a feature collection and explicitly rebuilding the selected day?s display.

## Evidence

Lesson 0002 is recorded as complete in the project handoff, including verification of feature dates, empty dates, and combined daily presentation.
