# Date lookup foundations

The user correctly explained CalendarView's zero-based month, why a date should map to a list of entries, and how a missing map key produces the default message. Future lessons can build on date keys, collections, and null handling.

## Evidence

The user answered all three retrieval questions from lesson 0001 correctly.
