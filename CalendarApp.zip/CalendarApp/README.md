Sandy H. 

Testing out mobile app development utilizing Andriod studio and Kotlin as a beginner to both. 

Goal : Create a Calendar based app







Features desired:

* Appointments through user inputs
* Period Tracking
* To-do List
* Habit Tracker
* The ability to have the habits be customizable to the frequency
* Notifications that are for each above feature. 

