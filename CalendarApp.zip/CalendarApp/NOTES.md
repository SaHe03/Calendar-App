# Teaching Notes

- The user wants guidance and explanation, not unsolicited code or file modifications.
- The user has prior experience with C++, C, Java, and Python.
- Teach by extending the existing CalendarView project in small steps.
- Use the hybrid model: feature-owned records are queried by date and combined in the daily view.
- Keep lessons tightly scoped to the Kotlin concept currently being learned; do not jump ahead into later architecture or Android APIs.
