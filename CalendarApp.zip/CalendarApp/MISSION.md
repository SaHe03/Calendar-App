# Mission: Learn Kotlin by building CalendarApp

## Why
Learn Kotlin through practical additions to a multipurpose Android calendar, so the user can understand and independently extend the application rather than merely paste generated code.

## Success looks like
- Explain how a selected calendar date becomes a lookup key.
- Add and display appointments or holidays associated with a date.
- Grow the prototype into persistent calendar, to-do, habit, and period-tracking features.

## Constraints
- Teach in small, testable steps using the current Android project.
- Never modify project code or files without the user's explicit permission.
- The user makes application-code changes during lessons.

## Out of scope
- Database persistence until the in-memory date lookup is understood.
- Automatic holiday APIs during the first lesson.
